<?php
error_reporting(0);
session_start();
if ($_SESSION['role'] != 1) {
    header("Location: login.php");
    exit();
}
require_once 'classes/Database.php';
require_once 'classes/User.php';
require_once 'classes/Admin.php';


$db = (new Database())->getConnection();
$admin = new Admin($db, $_SESSION['username'], '');

$message = "";
if ($_SERVER['REQUEST_METHOD'] == 'POST') {
	 $firstName = $_POST['first_name'];
    $lastName = $_POST['last_name'];
    $email = $_POST['email'];
    $phone = $_POST['phone'];
    $password = $_POST['auto_generate'] ? bin2hex(random_bytes(8)) : $_POST['password']; 
    $hashedPassword = password_hash($password, PASSWORD_DEFAULT);

    $admin->createUser($firstName, $lastName, $email,$phone,$password,$hashedPassword,2);
	$message = $admin->getMessage();
}
?>
<?php include 'includes/head.php'; ?>
   
      <div id="content" class="p-4 p-md-0">
    <?php include 'includes/header.php'; ?>
   <div class="p-md-5"> <h2 class="mb-4">Manage Users</h2>
     <?php if ($message): ?>
        <div class="alert <?php echo strpos($message, 'Error') === 0 ? 'alert-danger' : 'alert-success'; ?>" role="alert">
            <?php echo $message; ?>
        </div>
    <?php endif; ?>
    <form method="POST" class="bg-light p-4 rounded shadow-sm">
        <div class="form-group mb-3">
                <label>First Name</label>
                <input type="text" name="first_name" class="form-control" required>
            </div>
            <div class="form-group mb-3">
                <label>Last Name</label>
                <input type="text" name="last_name" class="form-control" required>
            </div>
            <div class="form-group mb-3">
                <label>Email</label>
                <input type="email" name="email" class="form-control" required>
            </div>
            <div class="form-group mb-3">
                <label>Phone</label>
                <input type="text" name="phone" class="form-control" required>
            </div>
            <div class="form-group form-check mb-3">
                <input type="checkbox" name="auto_generate" class="form-check-input">
                <label class="form-check-label">Auto-generate password</label>
            </div>
            <div class="form-group mb-3">
                <label>Password</label>
                <input type="password" name="password" class="form-control">
            </div>
            <button type="submit" class="btn btn-primary">Create User</button>
        </form>
</div></div>

<?php include 'includes/footer.php'; ?> 