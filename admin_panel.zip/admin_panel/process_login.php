<?php
session_start();
require_once 'classes/Database.php';
require_once 'classes/User.php';

$db = (new Database())->getConnection();
$username = $_POST['username'];
$password = $_POST['password'];

$user = new User($db, $username, $password);

if ($user->login()==1) {
    header("Location: index.php");
} 
else if ($user->login()==2) {

    header("Location: change_password.php");
}
else {
    echo "Invalid credentials!";
}
?>
