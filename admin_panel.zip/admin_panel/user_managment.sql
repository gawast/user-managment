-- phpMyAdmin SQL Dump
-- version 5.1.1
-- https://www.phpmyadmin.net/
--
-- Host: 127.0.0.1
-- Generation Time: Sep 21, 2024 at 11:53 AM
-- Server version: 10.4.19-MariaDB
-- PHP Version: 8.0.7

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
START TRANSACTION;
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;

--
-- Database: `user_managment`
--

-- --------------------------------------------------------

--
-- Table structure for table `tasks`
--

CREATE TABLE `tasks` (
  `id` int(11) NOT NULL,
  `user_id` int(11) DEFAULT NULL,
  `start_time` timestamp NOT NULL DEFAULT current_timestamp(),
  `stop_time` timestamp NOT NULL DEFAULT current_timestamp(),
  `notes` text DEFAULT NULL,
  `description` text DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

--
-- Dumping data for table `tasks`
--

INSERT INTO `tasks` (`id`, `user_id`, `start_time`, `stop_time`, `notes`, `description`) VALUES
(1, 4, '2024-09-12 08:40:00', '2024-09-21 11:40:00', 'testing', 'hello this description'),
(2, 6, '2024-09-05 09:26:00', '2024-09-29 09:26:00', 'hiuhiu', 'uyhiuyutyfytgfgv');

-- --------------------------------------------------------

--
-- Table structure for table `users`
--

CREATE TABLE `users` (
  `id` int(11) NOT NULL,
  `first_name` varchar(50) DEFAULT NULL,
  `last_name` varchar(50) DEFAULT NULL,
  `email` varchar(100) DEFAULT NULL,
  `phone` varchar(15) DEFAULT NULL,
  `password` varchar(255) DEFAULT NULL,
  `last_login` timestamp NULL DEFAULT NULL,
  `last_password_change` timestamp NULL DEFAULT NULL,
  `role` int(11) NOT NULL COMMENT '1=>admin,2=>user	',
  `flag` int(11) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

--
-- Dumping data for table `users`
--

INSERT INTO `users` (`id`, `first_name`, `last_name`, `email`, `phone`, `password`, `last_login`, `last_password_change`, `role`, `flag`) VALUES
(1, 'gawast', 'patel', 'gawastofficials@gmail.com', '7703090263', '$2y$10$86QYmoc4dNrHx/15oYRsHO7TWsXdr99DI.DOMCcTifUJoMC402kke', NULL, NULL, 1, 0),
(3, 'Gawast', 'Patel', 'gawast@gmail.com', '07703090263', '$2y$10$0ns0oDAynZ82CK2r4FQZI.8VONWOfkQIXOctt3NzIGsPx2jsSYlju', NULL, NULL, 2, 0),
(4, 'Gawast', 'Patel', 'a@gmail.com', '07703090263', '$2y$10$UzhAIyydt6YNufDuX5rCtOq/0AbGB2QJzW6ioCt94L.tsYS17lXUS', NULL, '2024-09-21 08:21:29', 2, 1),
(5, 'Gawast', 'Patel', 'admin@gmail.com', '07703090263', '$2y$10$TIEZfZs6Y3V4V8cWonXSw.6l9bopH5bH5Qo2OKSLgOpdIb71vGc/.', '2024-09-21 09:19:15', NULL, 2, 1),
(6, 'rishky', 'Patel', 'g@gmail.com', '07703090263', '$2y$10$OI7Ff/NMdZpNpAcEY3vT0.A0YIQ4AbT25DA9Ry7zEFHlADpfL9W.C', '2024-09-21 09:26:24', '2024-06-21 09:26:24', 2, 1);

--
-- Indexes for dumped tables
--

--
-- Indexes for table `tasks`
--
ALTER TABLE `tasks`
  ADD PRIMARY KEY (`id`),
  ADD KEY `user_id` (`user_id`);

--
-- Indexes for table `users`
--
ALTER TABLE `users`
  ADD PRIMARY KEY (`id`),
  ADD UNIQUE KEY `email` (`email`);

--
-- AUTO_INCREMENT for dumped tables
--

--
-- AUTO_INCREMENT for table `tasks`
--
ALTER TABLE `tasks`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=3;

--
-- AUTO_INCREMENT for table `users`
--
ALTER TABLE `users`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=7;

--
-- Constraints for dumped tables
--

--
-- Constraints for table `tasks`
--
ALTER TABLE `tasks`
  ADD CONSTRAINT `tasks_ibfk_1` FOREIGN KEY (`user_id`) REFERENCES `users` (`id`);
COMMIT;

/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
