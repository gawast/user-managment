<?php
class User {
    protected $db;
    protected $email;
    protected $password;
    protected $role;

    public function __construct($db, $email, $password) {
        $this->db = $db;
        $this->email = $email;
        $this->password = $password;
    }

   public function login() {
    $email = mysqli_real_escape_string($this->db, $this->email);
    $query = "SELECT * FROM users WHERE email = '$email'";
    $result = mysqli_query($this->db, $query);   
    $user = mysqli_fetch_assoc($result);
    if ($user && password_verify($this->password, $user['password'])) {
		
        $_SESSION['user_id']  = $user['id'];
        $_SESSION['username'] = $user['email'];
        $_SESSION['role']     = $user['role'];	
		if($user['role']==2){
        $lastChange           = new DateTime($user['last_password_change']);
        $now                  = new DateTime();
        $interval             = $now->diff($lastChange);

        if ($interval->days >= 30 || $user['flag']==0) {
			
             return 2;
             
        } 
		}
        return 1;
    }
    return false;
}


    public function getRole() {
        return $this->role;
    }
}
?>
