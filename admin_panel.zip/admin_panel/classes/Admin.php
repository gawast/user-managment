<?php
class Admin extends User {
    private $message = "";

    public function getMessage() {
        return $this->message;
    }

    public function createUser($firstName, $lastName, $newemail,$phone,$password,$hashedPassword,$role) {
        // Check if the email already exists
        $query = "SELECT * FROM users WHERE email = '$newemail'";
        $result = $this->db->query($query);

        if ($result->num_rows > 0) {
            $this->message = "Error: email '$newemail' already exists.";
            return;
        }

        // Proceed to insert the new user
        $insertQuery = "INSERT INTO users (first_name, last_name,phone,email, password, role) VALUES ('$firstName', '$lastName','$phone','$newemail', '$hashedPassword', '$role')";

        if ($this->db->query($insertQuery) === TRUE) {
            $this->message = "User created successfully: Username is $newemail ,Password is $password ";
        } else {
            $this->message = "Error: " . $this->db->error;
        }
    }

	 public function change_pass($newPassword) {      
        // Hash the new password
        $hashedPassword = password_hash($newPassword, PASSWORD_DEFAULT);

        // Prepare the update query
        $stmt = $this->db->prepare("UPDATE users SET password = ?, last_password_change = NOW() WHERE id = ?");
        
        // Bind the hashed password and user ID from session
        $stmt->bind_param("si", $hashedPassword, $_SESSION['user_id']);
        
        // Execute the query and check for success
        if ($stmt->execute()) {
            header("Location: index.php"); // Redirect on success
            exit();
        } else {
            echo "Error: " . $stmt->error;  // Output error message on failure
        }

        // Close the statement
        $stmt->close();
    }
}

?>
