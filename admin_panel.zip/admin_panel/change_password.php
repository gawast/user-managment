<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Change Password</title>
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.1.3/dist/css/bootstrap.min.css" rel="stylesheet">
</head>
<?php
session_start();
if ($_SESSION['role'] != 2) {
    header("Location: login.php");
    exit();
}
require_once 'classes/Database.php';
require_once 'classes/User.php';
require_once 'classes/Admin.php';


$db = (new Database())->getConnection();
$changePassword = new Admin($db, $_SESSION['username'], '');

$message = "";
if ($_SERVER['REQUEST_METHOD'] == 'POST') {
	
	
	$userId = $user['id']; 
    $stmt = $db->prepare("UPDATE users SET last_login = NOW(), flag = 1 WHERE id = ?");
    $stmt->bind_param("i", $_SESSION['user_id']);

    if ($stmt->execute()) {
        $new_password =$_POST['new_password']; 
        $changePassword->change_pass($new_password,);
	    $message = $admin->getMessage();
    }
	
	
	
   
}
?>

<body>
    <div class="container">
        <div class="row justify-content-center">
            <div class="col-md-6 mb-3">
               <h2>Change Password</h2>
           <form method="POST" class="bg-light p-4 rounded shadow-sm">
            <div class="form-group mb-2">
                <label>New Password *</label>
                <input type="password" name="new_password" class="form-control" required>
            </div>
            <button type="submit" class="btn btn-primary">Change Password</button>
        </form>
            </div>
        </div>
    </div>

    <script src="https://cdn.jsdelivr.net/npm/bootstrap@5.1.3/dist/js/bootstrap.bundle.min.js"></script>
</body>
</html>



