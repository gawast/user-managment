<?php
session_start();
if ($_SESSION['role'] !=1) {
    header("Location: login.php");
    exit();
}

require_once 'classes/Database.php';
require_once 'classes/User.php';
require_once 'classes/Admin.php';

// Initialize database connection and Admin class
$db = (new Database())->getConnection();
$admin = new Admin($db, $_SESSION['username'], '');

include 'includes/head.php'; 
?>

<div id="content" class="p-4 p-md-0">
    <?php include 'includes/header.php'; ?>
    <div class="p-md-5"> 
        <h2 class="mb-4">Task Reports</h2>
<a href="task_download_csv.php" class="btn btn-primary">Download Tasks Report</a>
        <table id="taskTable" class="table table-bordered table-striped">
        <thead>
             <tr>
                <th>User Name</th>
                <th>Email</th>
                <th>Start Time</th>
                <th>Stop Time</th>
                <th>Notes</th>
                <th>Description</th>
            </tr>
            </tr>
        </thead>
         <tbody>
            <?php
            // Fetch tasks and user details from the database
            $query = "
                SELECT 
                    tasks.start_time, 
                    tasks.stop_time, 
                    tasks.notes, 
                    tasks.description, 
                    users.first_name, 
                    users.last_name, 
                    users.email 
                FROM tasks 
                JOIN users ON tasks.user_id = users.id
            ";
            $result = $db->query($query);

            if ($result->num_rows > 0) {
                while ($row = $result->fetch_assoc()) {
                    $fullName = $row['first_name'] . ' ' . $row['last_name'];
                    echo "<tr>
                            <td>{$fullName}</td>
                            <td>{$row['email']}</td>
                            <td>{$row['start_time']}</td>
                            <td>{$row['stop_time']}</td>
                            <td>{$row['notes']}</td>
                            <td>{$row['description']}</td>
                          </tr>";
                }
            } else {
                echo "<tr><td colspan='6'>No tasks found</td></tr>";
            }
            ?>
        </tbody>
    </table>
    </div>
</div>

<?php include 'includes/footer.php'; ?>

<!-- Include jQuery and DataTables -->
<script src="https://code.jquery.com/jquery-3.6.0.min.js"></script>
<script src="https://cdn.datatables.net/1.11.5/js/jquery.dataTables.min.js"></script>
<script src="https://cdn.datatables.net/1.11.5/js/dataTables.bootstrap5.min.js"></script>

<!-- Initialize DataTable -->
<script>
    $(document).ready(function() {
        $('#taskTable').DataTable();
    });
</script>
