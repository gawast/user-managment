<?php
session_start();

if ($_SESSION['role'] != 1) {
    header("Location: login.php");
    exit();
}

require_once 'classes/Database.php';

$db = (new Database())->getConnection();
//$query = "SELECT start_time, stop_time, notes, description FROM tasks";
//$result = $db->query($query);

 $query = "
                SELECT 
                    tasks.start_time, 
                    tasks.stop_time, 
                    tasks.notes, 
                    tasks.description,                   
                    users.email 
                FROM tasks 
                JOIN users ON tasks.user_id = users.id
            ";
            $result = $db->query($query);

header('Content-Type: text/csv; charset=utf-8');
header('Content-Disposition: attachment; filename=user_tasks_report.csv');

// Create a file pointer connected to the output stream
$output = fopen('php://output', 'w');

// Output column headings for the CSV
fputcsv($output, array('Start Time', 'Stop Time', 'Notes', 'Description','Username'));

// Fetch and output each row of the data
if ($result->num_rows > 0) {
    while ($row = $result->fetch_assoc()) {
        fputcsv($output, $row);
    }
} else {
    echo "No tasks found.";
}

// Close the output stream
fclose($output);

// Close the database connection
$db->close();
